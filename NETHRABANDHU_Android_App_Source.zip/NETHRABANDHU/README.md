# NETHRABANDHU – Android-ready team app starter

This is a Progressive Web App (PWA) starter that can be installed from Chrome on Android.
It is designed for two users:
- Admin: creates camps and manages records.
- Team member: registers patients and updates assigned camp records.

Language: English only. Theme: green and white.

## Important before using real patient data
This is a starter project, not a certified medical-record system. Use fictional/demo data until:
1. Firebase Authentication is enabled.
2. Firestore security rules are deployed.
3. Admin and team accounts are assigned the correct roles.
4. You have reviewed consent, privacy, backup, and local legal requirements.

Never publish Firestore in test mode or make patient records publicly readable.

## 1. Create Firebase project
1. In Firebase Console, create a project.
2. Add a **Web app** (</> icon), nickname `NETHRABANDHU`.
3. Copy the Firebase web config.
4. In `public/firebase-config.js`, replace the placeholder values.
5. Enable Authentication → Sign-in method → Email/Password.
6. Create a Cloud Firestore database in production mode.
7. In Firestore, deploy the rules from `firestore.rules` (see below).

## 2. Create the two accounts
In Firebase Console → Authentication → Users, add the Admin and Team Member accounts using email/password.
Then in Firestore, create these documents in the `users` collection:
- Document ID = Admin user's Firebase Authentication UID; fields: `name` (string), `role` = `admin`
- Document ID = Team user's Firebase Authentication UID; fields: `name` (string), `role` = `member`

Do not let users choose their own role inside the app.

## 3. Deploy Firestore rules
In Firebase Console → Firestore Database → Rules, paste the contents of `firestore.rules` and Publish.
These rules require a signed-in user with a matching `users/{uid}` profile. Only admins can create camps. Signed-in team members can create patient records and screening/referral/follow-up records. Only admins can delete records.

## 4. Host the app
The simplest free route is Firebase Hosting. Hosting has plan quotas and terms; check current limits in Firebase Console.
For a laptop later:
- Install Node.js and Firebase CLI.
- From this project folder run `firebase login`
- Run `firebase init hosting` and select the existing project.
- Set public directory to `public`; configure as a single-page app: Yes.
- Run `firebase deploy`

For mobile-only editing, you can use a browser-based code editor such as Replit, but its free availability/limits may change. Upload this project there, add your Firebase config, and use its preview. You can also use GitHub Codespaces if available to your account; it may not be free.

## 5. Install on Android
After hosting:
1. Open the hosted HTTPS URL in Chrome on Android.
2. Open Chrome menu (⋮).
3. Tap `Install app` or `Add to Home screen`.
4. Confirm.

## App features in this starter
- Email/password login
- Role-based Admin / Team Member interface
- Patient registration and patient list
- Admin-only camp creation
- Camp list
- Screening record capture
- Sign out

## Current limitations
- No offline data synchronization.
- No automated appointment reminders.
- No medical diagnosis or treatment recommendations.
- No file/photo upload.
- No PDF reports yet.
- Add these only after testing and securing the core app.
