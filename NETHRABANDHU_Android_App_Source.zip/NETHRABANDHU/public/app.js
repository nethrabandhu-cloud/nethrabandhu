import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const $ = id => document.getElementById(id);
const loginView=$("loginView"), appView=$("appView");
let auth, db, currentUser=null, currentRole=null, patients=[], camps=[];
const configReady = firebaseConfig.apiKey !== "PASTE_API_KEY_HERE" && firebaseConfig.projectId !== "PASTE_PROJECT_ID";

function message(id,text,isError=true){$(id).textContent=text;$(id).style.color=isError?"#a43d2b":"#167447";}
function showApp(show){loginView.classList.toggle("hidden",show);appView.classList.toggle("hidden",!show);$("logoutBtn").classList.toggle("hidden",!show);}
function safe(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

if(configReady){
  const app=initializeApp(firebaseConfig); auth=getAuth(app); db=getFirestore(app);
  onAuthStateChanged(auth, async user=>{
    if(!user){currentUser=null;showApp(false);return;}
    currentUser=user;
    try{
      const {doc,getDoc}=await import("https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js");
      const profile=await getDoc(doc(db,"users",user.uid));
      if(!profile.exists() || !["admin","member"].includes(profile.data().role)){await signOut(auth);$("loginMessage").textContent="Your account is not authorised. Ask the administrator to assign your role.";return;}
      currentRole=profile.data().role;
      $("hello").textContent="Patients";
      $("roleLabel").textContent=`Signed in as ${profile.data().name || user.email} · ${currentRole==="admin"?"Administrator":"Team Member"}`;
      document.querySelectorAll(".admin-only").forEach(el=>el.classList.toggle("hidden",currentRole!=="admin"));
      showApp(true); await refreshData();
    }catch(e){showApp(false);$("loginMessage").textContent="Could not load your profile. Check Firestore rules and user role.";}
  });
}else{
  $("loginMessage").textContent="Setup required: add your Firebase web configuration in public/firebase-config.js.";
}

$("loginForm").addEventListener("submit",async e=>{e.preventDefault();if(!configReady)return message("loginMessage","Add Firebase configuration first.");try{await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value);}catch(err){message("loginMessage",err.message);}});
$("logoutBtn").addEventListener("click",()=>signOut(auth));
async function getRows(name){const snap=await getDocs(query(collection(db,name),orderBy("createdAt","desc")));return snap.docs.map(d=>({id:d.id,...d.data()}));}
async function refreshData(){
  try{[patients,camps]=await Promise.all([getRows("patients"),getRows("camps")]);renderPatients();renderCamps();renderSelects();$("patientCount").textContent=patients.length;$("campCount").textContent=camps.length;renderScreenings(await getRows("screenings"));}catch(e){console.error(e);$("patientList").innerHTML='<p class="empty">Unable to load records. Check database setup and security rules.</p>';}
}
function renderPatients(){$("patientList").innerHTML=patients.length?patients.map(p=>`<article class="record"><strong>${safe(p.name)}</strong><small>Age ${safe(p.age)} · ${safe(p.village)} · ${safe(p.phone||"No phone")}</small><small>${safe(p.campName||"No camp assigned")}</small></article>`).join(""):'<p class="empty">No patients registered yet.</p>';}
function renderCamps(){$("campList").innerHTML=camps.length?camps.map(c=>`<article class="record"><strong>${safe(c.name)}</strong><small>${safe(c.location)} · ${safe(c.date)}</small><small>Created by ${safe(c.createdBy||"Team")}</small></article>`).join(""):'<p class="empty">No camps created yet.</p>';}
function renderSelects(){const opts=camps.map(c=>`<option value="${safe(c.id)}">${safe(c.name)} – ${safe(c.location)}</option>`).join("");$("patientCamp").innerHTML='<option value="">No camp selected</option>'+opts;$("screenPatient").innerHTML='<option value="">Select patient</option>'+patients.map(p=>`<option value="${safe(p.id)}">${safe(p.name)}</option>`).join("");}
function renderScreenings(rows){$("screeningList").innerHTML=rows.length?rows.map(r=>`<article class="record"><strong>${safe(r.patientName)}</strong><small>${safe(r.action)} · ${safe(r.notes)}</small></article>`).join(""):'<p class="empty">No screening records yet.</p>';}
$("newPatientBtn").onclick=()=>$("patientForm").classList.remove("hidden");
$("cancelPatientBtn").onclick=()=>$("patientForm").classList.add("hidden");
$("newCampBtn").onclick=()=>$("campForm").classList.remove("hidden");
$("cancelCampBtn").onclick=()=>$("campForm").classList.add("hidden");
$("patientForm").addEventListener("submit",async e=>{e.preventDefault();try{const c=camps.find(x=>x.id===$("patientCamp").value);await addDoc(collection(db,"patients"),{name:$("patientName").value.trim(),age:Number($("patientAge").value),phone:$("patientPhone").value.trim(),village:$("patientVillage").value.trim(),campId:c?.id||"",campName:c?.name||"",createdBy:currentUser.email,createdAt:serverTimestamp()});e.target.reset();e.target.classList.add("hidden");message("patientMessage","Patient saved.",false);await refreshData();}catch(err){message("patientMessage","Could not save patient: "+err.message);}});
$("campForm").addEventListener("submit",async e=>{e.preventDefault();if(currentRole!=="admin")return message("campMessage","Only Admin can create camps.");try{await addDoc(collection(db,"camps"),{name:$("campName").value.trim(),location:$("campLocation").value.trim(),date:$("campDate").value,createdBy:currentUser.email,createdAt:serverTimestamp()});e.target.reset();e.target.classList.add("hidden");await refreshData();}catch(err){message("campMessage","Could not create camp: "+err.message);}});
$("screeningForm").addEventListener("submit",async e=>{e.preventDefault();try{const p=patients.find(x=>x.id===$("screenPatient").value);if(!p)throw new Error("Select a patient.");await addDoc(collection(db,"screenings"),{patientId:p.id,patientName:p.name,notes:$("screenNotes").value.trim(),action:$("screenAction").value,createdBy:currentUser.email,createdAt:serverTimestamp()});e.target.reset();message("screenMessage","Screening record saved.",false);await refreshData();}catch(err){message("screenMessage",err.message);}});
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));["patients","camps","screening"].forEach(t=>$(t+"Tab").classList.toggle("hidden",t!==btn.dataset.tab));$("hello").textContent=btn.textContent;}));
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(console.warn));
